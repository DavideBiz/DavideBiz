﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace ProgettoBiz
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        // dichiaro un vettore per contenere tutti i valori inseriti dall'utente
        decimal[] valori = new decimal[30];
        int indice = 0;
        public MainWindow()
        {
            InitializeComponent();
        }

        private void BtnInserisci_Click(object sender, RoutedEventArgs e)
        {
            // recupero i valori inseriti dall'utente
            valori[indice] = decimal.Parse(TxtValore.Text);
            indice++;

            Visualizza();
        }

        private void BtnCalcola_Click(object sender, RoutedEventArgs e)
        {
            /*    // recupero i valori inseriti dall'utente
               string primoStr = TxtPrimo.Text;
               string secondoStr = TxtSecondo.Text;
               string terzoStr = TxtTerzo.Text;

               // trasformare l'input in valori numerici
               decimal primo = decimal.Parse(primoStr);
               decimal secondo = decimal.Parse(secondoStr);
               decimal terzo = decimal.Parse(terzoStr);

               // eseguo il calcolo
               decimal media = (primo + secondo + terzo)/3;
           */
            decimal somma = 0;
            for (int i = 0; i < indice; i++)
            {
                somma = somma + valori[i];
            }
            decimal media = somma / indice;

            // mostro l'output all'utente
            LblRisultato.Content = media.ToString();
        }
        void Visualizza()
        {
            LstValori.Items.Clear();
            for (int i = 0; i < indice; i++)
            {
                LstValori.Items.Add(valori[i]);
            }
        }
    }
}
